# SubRecon
Bash tabanlı otomatik keşif ve ASM yardımcı aracı.

## Hızlı Başlangıç
```bash
chmod +x subrecon.sh
./subrecon.sh -h
```